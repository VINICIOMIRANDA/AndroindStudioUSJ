package br.usj.edu.exercicio2_USJ;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText qtdeCavalos;
    Button botaoCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        qtdeCavalos = findViewById(R.id.editCarvalos);
        botaoCalcular = findViewById(R.id.botaoCalcular);

        botaoCalcular.setOnClickListener(this);


    }

public void onClick(View view){
    Integer  qtde_Cavalos = Integer.parseInt(qtdeCavalos.getText().toString());
    Integer  calcular = this.caluladora(qtde_Cavalos);
    Toast.makeText(this, "A quantidade "+ calcular+" de ferraduras que devem ser compradas", Toast.LENGTH_SHORT).show();

}

private Integer caluladora(Integer quantidade){
    Integer ferraduras = 4;
    Integer cavalos = quantidade;

    Integer calcular = (ferraduras * cavalos);
    return calcular;

}

}