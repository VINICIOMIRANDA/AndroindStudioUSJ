package br.usj.edu.exercicio7_usj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText dia;
    EditText mes;
    Button botaCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dia = findViewById(R.id.editTextDia);
        mes = findViewById(R.id.editTextMes);
        botaCalcular = findViewById(R.id.botaoCalcular);
        botaCalcular.setOnClickListener(this);
        }

        public void onClick(View view){

        Integer v_dia = Integer.parseInt(dia.getText().toString());
        Integer v_mes = Integer.parseInt(mes.getText().toString());
        Integer quantosDias = this.calcularQTDias(v_dia, v_mes);

            if (quantosDias <= 360) {
                Toast.makeText(this, "O Total de dias desde do inicio do ano é : " + quantosDias+ " dias", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Erro na operação, favor refaça a operação considerando os meses 1 à 12", Toast.LENGTH_SHORT).show();


            }

        }

        public Integer calcularQTDias(Integer dia, Integer mes){


        Integer quantosDias = ((mes -1) * 30) + dia;

        return quantosDias;



        }

}