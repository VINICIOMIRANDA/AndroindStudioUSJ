package br.usj.edu.exercicio4_usj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText nome;
    EditText idade;
    Button calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       nome = findViewById(R.id.editTextNome);
       idade = findViewById(R.id.editTextIdade);
       calcular = findViewById(R.id.botaoCalcular);

        calcular.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {

    String v_nome = nome.getText().toString();
    Integer v_idade = Integer.parseInt(idade.getText().toString());
    Integer dias = this.calculoDias(v_idade);
        Toast.makeText(this, v_nome+", VOCÊ JÁ VIVEU "+dias+" DIAS.", Toast.LENGTH_SHORT).show();

    }

    private Integer calculoDias(Integer idade ){
        Integer dias = (idade * 365);
        return dias;

    }
}