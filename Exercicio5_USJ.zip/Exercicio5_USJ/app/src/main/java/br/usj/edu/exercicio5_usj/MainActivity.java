package br.usj.edu.exercicio5_usj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText precoGasolina;
    EditText precoPagamento;
    Button botaoCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        precoGasolina= findViewById(R.id.textEditGasolina);
        precoPagamento = findViewById(R.id.textEditPagamento);
        botaoCalcular = findViewById(R.id.botaoCalcular);

        botaoCalcular.setOnClickListener(this);


    }

    public void onClick (View view) {

        Double  precoG = Double.parseDouble(precoGasolina.getText().toString());
        Double  precoP = Double.parseDouble(precoPagamento.getText().toString());
        Double  litros = this.calcularLitros(precoG,precoP);
        Toast.makeText(this, "Você conseguiu abastecer "+litros+" de litros de gasolina", Toast.LENGTH_SHORT).show();
    }

    private Double calcularLitros (Double gasolina, Double pagamento){

        Double litros = (pagamento/gasolina);
        return litros;

    
}

}