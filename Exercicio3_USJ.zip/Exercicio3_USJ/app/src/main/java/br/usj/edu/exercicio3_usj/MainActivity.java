package br.usj.edu.exercicio3_usj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText pao;
    EditText broa;
    Button calcularBotao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pao = findViewById(R.id.editTextPaes);
        broa = findViewById(R.id.editTextBroa);
        calcularBotao = findViewById(R.id.botaoCalcular);

        calcularBotao.setOnClickListener(this);



    }

    public void onClick (View view){

        Double valorPao = Double.parseDouble(pao.getText().toString());
        Double valorBroa = Double.parseDouble(broa.getText().toString());
        Double totalArreacado =this.calculadoraTotalArrecadado(valorPao,valorBroa);
        Double arrecadacaoPoupanca = this.poupancaArrecadacao(totalArreacado);
        Toast.makeText(this, "O valor total arrecadado R$"+totalArreacado, Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "O valor a ser depositado é R$"+arrecadacaoPoupanca.toString(), Toast.LENGTH_SHORT).show();
    }

    private Double calculadoraTotalArrecadado(Double vpao, Double vbroa){
        Double totalArreacado = (vpao * 0.12) + (vbroa * 1.50);
        return totalArreacado;

    }

    private Double poupancaArrecadacao(Double total){
     

        Double arrecadacao = (total / 10);
        Double arrecadacaoPoupanca = arrecadacao;
        return arrecadacaoPoupanca;

    }

}