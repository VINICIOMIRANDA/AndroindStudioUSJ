package br.usj.edu.exercicio1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText altura;
    EditText base;
    Button botaoCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        altura = findViewById(R.id.editTextAltura);
        base = findViewById(R.id.editTextBase);
        botaoCalcular = findViewById(R.id.botaoCalcular);

        botaoCalcular.setOnClickListener(this);




    }
        @Override
        public void onClick(View view){
        Double valorAltura = Double.parseDouble(altura.getText().toString());
        Double valorBase = Double.parseDouble(base.getText().toString());
        Double area = this.calculaArea(valorAltura,valorBase);
            Toast.makeText(this, "Á área do terreno é "+area.toString()+ " cm² " , Toast.LENGTH_SHORT).show();

    }
    private Double calculaArea(Double altura, Double base){
        Double area = (altura * base);
        return area;
    }
}