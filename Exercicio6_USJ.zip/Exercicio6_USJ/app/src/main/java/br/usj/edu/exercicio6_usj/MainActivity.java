package br.usj.edu.exercicio6_usj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText pesoPrato;
    EditText pesoPCliente;
    Button botaCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pesoPrato = findViewById(R.id.editTextPrato);
        pesoPCliente = findViewById(R.id.editTextPratoCliente);
        botaCalcular = findViewById(R.id.botaoCalcular);
        botaCalcular.setOnClickListener(this);

    }
        @Override
        public void onClick(View view) {
            Double prato = Double.parseDouble(pesoPrato.getText().toString());
            Double pratoCliente = Double.parseDouble(pesoPCliente.getText().toString());
            Double valorPrato = this.calularPesoValor(prato,pratoCliente);
            Toast.makeText(this, "O valor a Pagar é R$"+valorPrato, Toast.LENGTH_SHORT).show();

    }

    private Double calularPesoValor(Double pesoPrato, Double pesoPCliente){
        Double valorK = 12.00;
        Double pesoReal = (pesoPCliente - pesoPrato);
        Double valorPrato = (pesoReal * valorK)/1000;
        return valorPrato;

    }
}